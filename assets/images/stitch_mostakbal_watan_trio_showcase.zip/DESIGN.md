---
name: Nile Tech Vanguard
colors:
  surface: '#0e1321'
  surface-dim: '#0e1321'
  surface-bright: '#343948'
  surface-container-lowest: '#090e1c'
  surface-container-low: '#161b2a'
  surface-container: '#1a1f2e'
  surface-container-high: '#252a39'
  surface-container-highest: '#303444'
  on-surface: '#dee2f6'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#dee2f6'
  inverse-on-surface: '#2b303f'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#ffbcbf'
  on-tertiary: '#67001b'
  tertiary-container: '#ff929a'
  on-tertiary-container: '#8c0028'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b7'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#92002a'
  background: '#0e1321'
  on-background: '#dee2f6'
  surface-variant: '#303444'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 68px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  gutter-mobile: 1rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style
The design system positions next-generation Egyptian tech talent on par with premier global software engineering academies. The brand ethos embodies executive prestige, intellectual rigor, and forward-looking digital craftsmanship. Rejecting antiquated regional clichés of basic gold foil and flat emerald greens, this system adopts a hyper-modern, nocturnal aesthetic engineered to inspire ambitious youth across Cairo, Alexandria, and beyond.

The visual direction merges **refined tech glassmorphism** with **high-precision structural minimalism**. Surfaces evoke polished obsidian, tinted acrylic, and low-emissivity glass bathed in calibrated midnight ambient lighting. Subtle micro-directional gradients, surgical luminous borders, and micro-luminescent indicators give interactive elements an authoritative yet dynamic presence. The emotional resonance is calm, empowering, and uncompromisingly professional—treating young learners as future chief architects and technical founders.

## Colors
The palette is rooted in an ultra-deep, architectural midnight spectrum designed specifically for high-focus dark mode learning environments.

- **Canvas & Surface Architecture**:
  - `canvas-root`: `#0a0f1d` (Deepest nocturnal obsidian).
  - `surface-base`: `#0f172a` (Rich slate navy for foundational sections).
  - `surface-raised`: `#1e293b` (Tonal layer for interactive panels, modules, and elevated workspaces).
  - `surface-overlay`: `rgba(30, 41, 59, 0.65)` (Glassmorphic tier with blur).

- **Primary Electric Sapphire & Cyan Core**:
  - `primary`: `#38bdf8` (Electric sky/sapphire glow for primary actions, current milestones, and active code vectors).
  - `primary-interactive`: `#0284c7` (Deep sapphire hover/pressed states).
  - `primary-glow`: `rgba(56, 189, 248, 0.15)` (Subtle backlights for high-priority elements).

- **Secondary Luminous Violet**:
  - `secondary`: `#6366f1` (Refined cobalt-violet for advanced tracks, AI/Machine Learning specializations, and mentorship cues).
  - `secondary-subtle`: `rgba(99, 102, 241, 0.12)` (Container background for specialized tracks).

- **Tertiary Amber-Rose Accent**:
  - `tertiary`: `#f43f5e` (Warm amber-rose used sparingly for live masterclasses, deadline alerts, streaks, and standout badges).

- **Text & High-Contrast Readability**:
  - `text-primary`: `#f8fafc` (Pristine, crisp optical white).
  - `text-secondary`: `#94a3b8` (Balanced icy slate for metadata, secondary labels, and descriptive briefs).
  - `text-muted`: `#64748b` (Deep slate for tertiary footnotes, inactive steps, and border guides).
  - `border-structural`: `rgba(51, 65, 85, 0.6)` (Discrete, surgical separations).
  - `border-luminous`: `rgba(56, 189, 248, 0.25)` (Accent borders on hover or focus).

## Typography
The system employs an authoritative duo: **Space Grotesk** for display titles, metrics, section heads, and badges, imparting a calibrated engineering tone; and **Plus Jakarta Sans** for body and interface communication, delivering geometric clarity and effortless scanning. When rendered in Arabic locales, the platform harmoniously pairs with **Cairo** for bold display metrics and **Tajawal** for fluid, highly legible interface copy, maintaining identical optical weights and vertical grid alignments.

Typography scales dynamically across viewports. Headlines leverage negative tracking to reinforce structural density, while uppercase micro-labels utilize wide kerning for swift status recognition.

## Layout & Spacing
The layout follows a responsive 12-column dynamic fluid grid architecture on desktop and tablet, collapsing to a structured 4-column flow on mobile screens.

- **Breakpoints**:
  - `Mobile`: `< 640px` (4 columns, `margin-mobile: 1.25rem`, `gutter-mobile: 1rem`).
  - `Tablet`: `640px – 1024px` (8 columns, `margin: 1.5rem`, `gutter: 1.5rem`).
  - `Desktop`: `> 1024px` (12 columns, max-width: 1440px centered, `margin: 2rem`, `gutter: 1.5rem`).

Vertical pacing enforces rhythmic structure through standard multipliers of `8px`. Section transitions rely on `space-2xl` to establish air and intentionality, avoiding dense, claustrophobic dashboard patterns while ensuring curriculum maps, code consoles, and project showcases sit inside balanced bounding frames.

## Elevation & Depth
Elevation is achieved via disciplined layering, frosted optical refraction, and ambient illumination rather than conventional opaque drop shadows.

- **Surface Tiers**:
  - **Tier 0 (Root Canvas)**: Solid `#0a0f1d`. Unlit, background layer.
  - **Tier 1 (Panels & Shells)**: `#0f172a` with a 1px continuous border (`rgba(51, 65, 85, 0.4)`).
  - **Tier 2 (Interactive Modules & Cards)**: Frosted `rgba(30, 41, 59, 0.55)` complemented by a `16px` backdrop-blur filter and an inner hairline reflection along the top edge (`inset 0 1px 0 0 rgba(255, 255, 255, 0.08)`).
  - **Tier 3 (Floating Modals, Drawers & Command Menus)**: Deep translucent slate `rgba(15, 23, 42, 0.85)` with `24px` backdrop blur, framed by an accent-tinted border (`rgba(56, 189, 248, 0.3)`) and an expansive, low-opacity ambient bloom (`0 20px 40px -15px rgba(2, 6, 23, 0.9), 0 0 30px -10px rgba(56, 189, 248, 0.15)`).

- **Glow Accents**: Active interactive states omit harsh drop shadows in favor of subtle directional phosphorescence (e.g., a 12px outer glow at 20% opacity matching the primary sapphire or secondary violet tone).

## Shapes
The design system adopts a balanced, refined contour language (Level 2 - Rounded). Geometric precision remains central: controls avoid juvenile hyper-pill aesthetics while eliminating abrasive sharp corners.

- Buttons, inputs, and tab containers feature `0.5rem` (`8px`) radii.
- Medium components, curriculum nodes, and code viewports use `1rem` (`16px`) radii (`rounded-lg`).
- High-level containers, showcase panels, and modal dialogs use `1.5rem` (`24px`) radii (`rounded-xl`).
- Status indicators, tag counters, and technical chip components maintain pill shapes (`9999px`) to emphasize atomic granularity.

## Components

### Buttons
- **Primary Action**: Electric sapphire background (`#38bdf8`) with midnight navy label text (`#0a0f1d`), bold weight. Subtle inner highlight and a faint cyan ambient glow on hover (`0 0 20px rgba(56, 189, 248, 0.35)`). Active state applies a micro-scale of `0.98`.
- **Secondary (Glass)**: Tinted translucent fill (`rgba(30, 41, 59, 0.6)`), 1px border of `rgba(148, 163, 184, 0.2)`, white text. Hover transitions border to `rgba(56, 189, 248, 0.6)` with a slight light-lift.
- **Ghost/Tertiary**: Transparent background, slate text (`#94a3b8`), shifting to `#f8fafc` with subtle violet backplate on interaction.

### Cards & Curriculum Modules
Cards transcend basic flat containers:
- Layered acrylic styling using `rgba(15, 23, 42, 0.75)` backdrop blur.
- Dual-border treatment: exterior 1px border in `rgba(51, 65, 85, 0.6)` paired with a subtle linear gradient border top-to-bottom (`rgba(56, 189, 248, 0.4)` to `transparent`).
- Integrated status line or glowing milestone indicator on the upper rim signaling difficulty, active progress, or live status.

### Badges & Technical Chips
- **Curriculum / Tech Stack Tags**: High-density micro-badges with `0.75rem` vertical padding, `Space Grotesk` uppercase text, dark indigo/slate background (`rgba(30, 41, 59, 0.8)`), and border matched to topic color (Cyan for Frontend/Cloud, Violet for AI/Backend, Amber-Rose for Live Challenges).

### Form Inputs & Terminal Fields
- Dark recessed background (`#070b14`), inset border (`rgba(51, 65, 85, 0.8)`), text in `#f8fafc`.
- Focus state: hairline glow with an animated shift to `rgba(56, 189, 248, 0.8)` and a soft ambient field surrounding the container.
- Labels sit outside or as micro-caps above the input field with monospaced format indicators.

### Checkboxes & Segmented Selectors
- Custom squircle checkbox (`6px` radius) with deep slate borders; selected state transitions to full electric cyan fill with a midnight check glyph.
- Segmented tab switchers feature a unified recessed trench (`#0a0f1d`) with a sliding, glassmorphic active pill indicator.

### Specialized Platform Elements
- **Code Console Container**: Obsidian bezel (`#050811`), integrated tab bar with dot indicators, syntax color-coded to match the cyan/violet/rose triadic hierarchy.
- **Milestone Radar & Track Progress**: Sleek multi-tiered progress lines utilizing gradient fills from `#6366f1` to `#38bdf8`, paired with pulsing status beacons for live lectures and peer reviews.